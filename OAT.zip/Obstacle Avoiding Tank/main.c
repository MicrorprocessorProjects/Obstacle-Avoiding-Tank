#include <msp430.h>

int value=0, i=0 ;
int power = 0;
int distance;
int ADCReading [3];

// Function Prototypes
void fadeLED(int speed);
void ConfigureAdc(void);
void getanalogvalues();


int main(void){
	WDTCTL = WDTPW + WDTHOLD;                 	// Stop WDT


	P1OUT = 0;
	P2OUT = 0;
	P1DIR = 0;
	P1REN = 0;
	P2REN = 0;
	P2DIR = 0;

	P2DIR |= (BIT0| BIT1| BIT2| BIT3 | BIT4);	// set bit0, 1, 2, 3 & 4 as output

	ConfigureAdc(); 		//initializes the configuration for the IR sensor

	for (;;){
		// reading distance repeatedly at the beginning of the main loop
		getanalogvalues();
//		fadeLED(speed);		// sets speed for turning motor

		if(distance <= 900 && distance >= 500){	//if obstacle is closer than 50cm from the tank
//			speed=25;
			P2OUT |= BIT0;								//turns LED on confirming sensor sensed an obstacle
			P2OUT &= ~BIT2; __delay_cycles(10000);		//turns off forward motion
			while(BIT2 & BUSY);							//waits for tank to come to full stop
			P2OUT |= BIT4; __delay_cycles(50000);		//BIT4 turns on turning the vehicle
			while(BIT4 & BUSY);							//waits for turning to complete
			P2OUT |= BIT1; __delay_cycles(100000);			//reverses forward motion
			while(BIT1 & BUSY);							//waits for reverse motion to complete
			P2OUT &= ~BIT1;								//turns off reverse motion
			P2OUT &= ~BIT4;								//turns turning motor off making vehicle straighten
		}else{

//		   	speed--;
//		   	if(speed<5){speed=0;}
			P2OUT &= ~BIT0;							//turns off LED noting sensor is not sensing anything
			P2OUT |= BIT2;							//turns forward motion on
		}
	}
}





void ConfigureAdc()
{
   ADC10CTL1 = INCH_2 | CONSEQ_1; 				// A2 + A1 + A0, single sequence
   ADC10CTL0 = ADC10SHT_2 | MSC | ADC10ON;
   while (ADC10CTL1 & BUSY);
   ADC10DTC1 = 0x03; 							// 3 conversions
   ADC10AE0 |= (BIT0); 			// ADC10 option select
}
/*
void fadeLED(int speed)
{
	P1SEL |= (BIT6);                    	    // P1.0 and P1.6 TA1/2 options
	CCR0 = 100-1;                            	// PWM Period
	CCTL1 = OUTMOD_3;                           // CCR1 reset/set
	CCR1 = speed;	                                // CCR1 PWM duty cycle
	TACTL = TASSEL_2 + MC_1; 					// tur on

}
*/
void getanalogvalues()
{
 i = 0; power = 0; distance =0;                // set all analog values to zero
	for(i=1; i<=5 ; i++)                              // read all three analog values 5 times each and average
  {
    ADC10CTL0 &= ~ENC;
    while (ADC10CTL1 & BUSY);                         //Wait while ADC is busy
    ADC10SA = (unsigned)&ADCReading[0]; 			  //RAM Address of ADC Data, must be reset every conversion
    ADC10CTL0 |= (ENC | ADC10SC);                     //Start ADC Conversion
    while (ADC10CTL1 & BUSY);                         //Wait while ADC is busy
    distance += ADCReading[1];
//    power += ADCReading[2];
  }
 distance = distance/5;								     // Average the 5 reading for the three variables
}


#pragma vector=ADC10_VECTOR
__interrupt void ADC10_ISR(void)
{
	__bic_SR_register_on_exit(CPUOFF);
}
